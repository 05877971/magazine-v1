
export interface Post {
  id: string;
  content: string;
  created_by_name: string;
  created_by_email: string;
  created_by_profile_image: string;
  parent_post_id: string | null;
  reply_count: number;
  view_count: number;
  reactions: { [key: string]: string[] }; // emoji -> list of user emails
  created_at: string;
  quoted_post?: Post;
}

export interface User {
  email: string;
  name: string;
  profile_image_url: string;
  is_admin: boolean;
  can_write: boolean;
}

export interface NewsDraft {
  id: string;
  source: string;
  content: string;
  is_published: boolean;
}

export type ReportStatus = 'pending' | 'reviewed' | 'resolved';

export interface Report {
  id: string;
  post_id: string;
  post_content: string;
  reason: string;
  reporter_email: string;
  status: ReportStatus;
}

export interface SystemSettings {
  channel_name: string;
  channel_logo: string;
  channel_description: string;
  default_new_user_can_write: boolean;
  categories: string[];
  reaction_emojis: string[];
  webhook_url: string;
}
