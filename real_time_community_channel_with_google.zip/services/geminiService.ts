
import { GoogleGenAI } from "@google/genai";

// This is a mock function for demonstration purposes.
// In a real application, you would use the Gemini API.
// The API key is assumed to be in process.env.API_KEY
export const fetchNewsFromSource = async (source: string): Promise<string> => {
  if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Using mock data.");
    return new Promise((resolve) =>
      setTimeout(() => {
        resolve(
          `## כותרת ראשית מ: ${source}\n\nזוהי ידיעה לדוגמה שנשלפה ממקור חיצוני. הבינה המלאכותית סבורה שזוהי ידיעה חשובה מאוד.\n\n* נקודה ראשונה\n* נקודה שנייה\n* נקודה שלישית\n\nלסיכום, העתיד נראה מבטיח.`
        );
      }, 1500)
    );
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Please act as a news summarizer. Fetch the latest important news from the Telegram channel "${source}" and provide a concise summary in Hebrew. The summary should be well-formatted using Markdown.`,
    });
    return response.text;
  } catch (error) {
    console.error("Error fetching from Gemini API:", error);
    return `שגיאה בשליפת מידע מ-${source}. אנא נסה שוב מאוחר יותר.`;
  }
};
