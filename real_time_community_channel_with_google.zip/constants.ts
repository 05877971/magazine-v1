
import { User, Post, SystemSettings, NewsDraft, Report } from './types';

export const ADMIN_EMAIL = 'eliyahucohen0@gmail.com';

export const MOCK_USERS: User[] = [
  {
    email: ADMIN_EMAIL,
    name: "אליהו כהן (מנהל)",
    profile_image_url: "https://picsum.photos/seed/admin/100/100",
    is_admin: true,
    can_write: true,
  },
  {
    email: "writer@example.com",
    name: "יוסי לוי (כותב)",
    profile_image_url: "https://picsum.photos/seed/writer/100/100",
    is_admin: false,
    can_write: true,
  },
  {
    email: "user@example.com",
    name: "שרה ישראלי (משתמשת)",
    profile_image_url: "https://picsum.photos/seed/user/100/100",
    is_admin: false,
    can_write: false,
  },
];

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post1',
    content: '<b>ברוכים הבאים לערוץ הקהילה החדש!</b>\nכאן תוכלו להתעדכן בכל מה שחדש וחשוב.\nמוזמנים להגיב ולהיות חלק מהשיח.',
    created_by_name: 'אליהו כהן (מנהל)',
    created_by_email: ADMIN_EMAIL,
    created_by_profile_image: 'https://picsum.photos/seed/admin/100/100',
    parent_post_id: null,
    reply_count: 1,
    view_count: 150,
    reactions: { '👍': [ADMIN_EMAIL, 'user@example.com'], '❤️': ['writer@example.com'] },
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: 'post2',
    content: 'איזה יופי! שמח להיות פה.',
    created_by_name: 'יוסי לוי (כותב)',
    created_by_email: 'writer@example.com',
    created_by_profile_image: 'https://picsum.photos/seed/writer/100/100',
    parent_post_id: 'post1',
    reply_count: 0,
    view_count: 95,
    reactions: { '🚀': [ADMIN_EMAIL] },
    created_at: new Date(Date.now() - 1000 * 60 * 60 * 1).toISOString(),
  },
  {
    id: 'post3',
    content: 'עדכון חשוב: מחר יתקיים מפגש קהילה בזום בשעה 19:00. פרטים נוספים יפורסמו בהמשך.',
    created_by_name: 'אליהו כהן (מנהל)',
    created_by_email: ADMIN_EMAIL,
    created_by_profile_image: 'https://picsum.photos/seed/admin/100/100',
    parent_post_id: null,
    reply_count: 0,
    view_count: 120,
    reactions: {},
    created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
  },
];

export const INITIAL_SYSTEM_SETTINGS: SystemSettings = {
  channel_name: 'ערוץ הקהילה שלי',
  channel_logo: 'https://picsum.photos/seed/logo/200/200',
  channel_description: 'זהו תיאור קצר של הערוץ. כאן תוכלו למצוא את כל העדכונים, החדשות והדיונים הכי חמים בקהילה שלנו. הרגישו חופשי להשתתף!',
  default_new_user_can_write: false,
  categories: ['כללי', 'עדכונים', 'טכנולוגיה'],
  reaction_emojis: ['👍', '❤️', '😂', '😯', '😢', '🔥', '🚀'],
  webhook_url: 'https://api.example.com/webhook',
};

export const INITIAL_DRAFTS: NewsDraft[] = [
  { id: 'draft1', source: 'Telegram: Tech News', content: 'מנכ"ל OpenAI הכריז על מודל חדש ופורץ דרך בתחום הוידאו.', is_published: false },
  { id: 'draft2', source: 'Telegram: Market Updates', content: 'שוק המטבעות הדיגיטליים חווה תנודתיות גבוהה ביממה האחרונה.', is_published: true },
];

export const INITIAL_REPORTS: Report[] = [
  { id: 'report1', post_id: 'post2', post_content: 'איזה יופי! שמח להיות פה.', reason: 'ספאם', reporter_email: 'user@example.com', status: 'pending' },
];
