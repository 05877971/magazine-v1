
import React, { useState, useCallback } from 'react';
import { Post, User, SystemSettings, NewsDraft, Report, ReportStatus } from './types';
import { MOCK_USERS, INITIAL_POSTS, INITIAL_SYSTEM_SETTINGS, INITIAL_DRAFTS, INITIAL_REPORTS } from './constants';
import { Header } from './components/Header';
import { Feed } from './components/Feed';
import { AdminPanel } from './components/AdminPanel';
import { NewsSources } from './components/NewsSources';
import GoogleSignInReplaceChoice from './components/GoogleSignInReplaceChoice';

type Page = 'feed' | 'admin' | 'news';

const App: React.FC = () => {
    const [page, setPage] = useState<Page>('feed');
    const [currentUser, setCurrentUser] = useState<User | null>(null);

    // Data States
    const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
    const [users, setUsers] = useState<User[]>(MOCK_USERS);
    const [settings, setSettings] = useState<SystemSettings>(INITIAL_SYSTEM_SETTINGS);
    const [drafts, setDrafts] = useState<NewsDraft[]>(INITIAL_DRAFTS);
    const [reports, setReports] = useState<Report[]>(INITIAL_REPORTS);
    
    // --- AUTH ---
    const handleLogin = useCallback((user: User) => {
        setCurrentUser(user);
        setPage('feed');
    }, []);

    const handleLogout = useCallback(() => {
        setCurrentUser(null);
        setPage('feed');
    }, []);
    
    // --- POSTS ---
    const addPost = async (content: string, parentId: string | null, quotedPost?: Post) => {
        if (!currentUser) return;
        const newPost: Post = {
            id: `post${Date.now()}`,
            content,
            created_by_name: currentUser.name,
            created_by_email: currentUser.email,
            created_by_profile_image: currentUser.profile_image_url,
            parent_post_id: parentId,
            reply_count: 0,
            view_count: 0,
            reactions: {},
            created_at: new Date().toISOString(),
            quoted_post: quotedPost,
        };
        setPosts(prev => [...prev, newPost]);
        if (parentId) {
            setPosts(prev => prev.map(p => p.id === parentId ? {...p, reply_count: p.reply_count + 1} : p));
        }
    };
    
    const updatePost = async (postId: string, content: string) => {
      setPosts(prev => prev.map(p => p.id === postId ? { ...p, content } : p));
    };

    const deletePost = async (postId: string) => {
      if (window.confirm('האם אתה בטוח שברצונך למחוק את ההודעה?')) {
        setPosts(prev => prev.filter(p => p.id !== postId && p.parent_post_id !== postId));
      }
    };
    
    const addReaction = async (postId: string, emoji: string) => {
      if (!currentUser) return;
      setPosts(prev => prev.map(p => {
        if (p.id === postId) {
          const newReactions = { ...p.reactions };
          const usersForEmoji = newReactions[emoji] || [];
          if (usersForEmoji.includes(currentUser.email)) {
            newReactions[emoji] = usersForEmoji.filter(email => email !== currentUser.email);
          } else {
            newReactions[emoji] = [...usersForEmoji, currentUser.email];
          }
          return { ...p, reactions: newReactions };
        }
        return p;
      }));
    };

    // --- USERS ---
    const updateUser = async (email: string, updates: Partial<User>) => {
      setUsers(prev => prev.map(u => u.email === email ? { ...u, ...updates } : u));
    };
    
    // --- REPORTS ---
    const addReport = async (post: Post, reason: string) => {
        if (!currentUser) return;
        const newReport: Report = {
            id: `report${Date.now()}`,
            post_id: post.id,
            post_content: post.content.substring(0, 100),
            reason,
            reporter_email: currentUser.email,
            status: 'pending'
        };
        setReports(prev => [...prev, newReport]);
    };

    const updateReportStatus = async (id: string, status: ReportStatus) => {
        setReports(prev => prev.map(r => r.id === id ? { ...r, status } : r));
    };
    
    // --- NEWS DRAFTS ---
    const addDraft = async (draft: Omit<NewsDraft, 'id' | 'is_published'>) => {
        const newDraft: NewsDraft = { ...draft, id: `draft${Date.now()}`, is_published: false };
        setDrafts(prev => [newDraft, ...prev]);
    };

    const updateDraft = async (id: string, content: string) => {
        setDrafts(prev => prev.map(d => d.id === id ? { ...d, content } : d));
    };
    
    const deleteDraft = async (id: string) => {
        setDrafts(prev => prev.filter(d => d.id !== id));
    };

    const publishDraft = async (draft: NewsDraft) => {
        if (!currentUser) return;
        await addPost(draft.content, null);
        setDrafts(prev => prev.map(d => d.id === draft.id ? { ...d, is_published: true } : d));
    };

    const renderPage = () => {
        if (page === 'admin' && currentUser?.is_admin) {
            return <AdminPanel 
                users={users}
                settings={settings}
                reports={reports}
                updateUser={updateUser}
                setSettings={setSettings}
                updateReportStatus={updateReportStatus}
            />;
        }
        if (page === 'news' && (currentUser?.is_admin || currentUser?.can_write)) {
            return <NewsSources 
                drafts={drafts}
                addDraft={addDraft}
                updateDraft={updateDraft}
                deleteDraft={deleteDraft}
                publishDraft={publishDraft}
            />;
        }
        return <Feed 
            posts={posts}
            users={users}
            settings={settings}
            currentUser={currentUser}
            addPost={addPost}
            updatePost={updatePost}
            deletePost={deletePost}
            addReaction={addReaction}
            addReport={addReport}
        />;
    };

    return (
        <div className="min-h-screen bg-gray-50 text-gray-900">
            <Header
                channelName={settings.channel_name}
                currentUser={currentUser}
                page={page}
                setPage={setPage}
                onLogin={handleLogin}
                onLogout={handleLogout}
            />
            <main>
                {renderPage()}
            </main>
        </div>
    );
};

export default App;
