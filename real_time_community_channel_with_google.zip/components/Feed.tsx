
import React, { useState, useEffect, useRef } from 'react';
import { Post, User, SystemSettings } from '../types';
import { PostCard } from './PostCard';
import { RichTextEditor } from './RichTextEditor';

interface FeedProps {
  posts: Post[];
  users: User[];
  settings: SystemSettings;
  currentUser: User | null;
  addPost: (content: string, parentId: string | null, quotedPost?: Post) => Promise<void>;
  updatePost: (postId: string, content: string) => Promise<void>;
  deletePost: (postId: string) => Promise<void>;
  addReaction: (postId: string, emoji: string) => Promise<void>;
  addReport: (post: Post, reason: string) => Promise<void>;
}

export const Feed: React.FC<FeedProps> = ({ posts, settings, currentUser, addPost, updatePost, deletePost, addReaction, addReport }) => {
  const [isSending, setIsSending] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Post | null>(null);
  const [quoting, setQuoting] = useState<Post | null>(null);
  const [editing, setEditing] = useState<Post | null>(null);
  const [threadView, setThreadView] = useState<Post | null>(null);
  const editorRef = useRef<HTMLDivElement>(null);
  const feedEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    feedEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [posts, threadView]);

  const handleSend = async (content: string) => {
    setIsSending(true);
    if (editing) {
      await updatePost(editing.id, content);
      setEditing(null);
    } else {
      await addPost(content, replyingTo?.id || null, quoting || undefined);
      setReplyingTo(null);
      setQuoting(null);
    }
    setIsSending(false);
  };

  const handleAction = (setter: React.Dispatch<React.SetStateAction<Post | null>>) => (post: Post) => {
    setter(post);
    setEditing(null); // Cancel editing if another action is taken
    editorRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleEdit = (post: Post) => {
    setReplyingTo(null);
    setQuoting(null);
    setEditing(post);
    editorRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleReport = async (post: Post) => {
    const reason = prompt(`נא לציין את סיבת הדיווח על ההודעה:`);
    if (reason) {
      await addReport(post, reason);
      alert('הדיווח נשלח בהצלחה. תודה!');
    }
  };
  
  const cancelActions = () => {
    setReplyingTo(null);
    setQuoting(null);
    setEditing(null);
  };

  const getThreadPosts = () => {
    if (!threadView) return [];
    return posts.filter(p => p.id === threadView.id || p.parent_post_id === threadView.id);
  };

  const rootPosts = posts.filter(p => !p.parent_post_id);

  const canWrite = currentUser?.can_write || currentUser?.is_admin || false;
  
  const renderPosts = (postList: Post[]) => postList.map(post => (
    <PostCard
      key={post.id}
      post={post}
      currentUserEmail={currentUser?.email || null}
      canWrite={canWrite}
      isAdmin={currentUser?.is_admin || false}
      reactionEmojis={settings.reaction_emojis}
      onReply={handleAction(setReplyingTo)}
      onQuote={handleAction(setQuoting)}
      onEdit={handleEdit}
      onDelete={deletePost}
      onReport={handleReport}
      onReaction={addReaction}
      onShowThread={setThreadView}
    />
  ));

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8">
      {/* Channel Header */}
      <div className="text-center mb-8">
        <img src={settings.channel_logo} alt="Channel Logo" className="w-24 h-24 rounded-full mx-auto mb-4" />
        <h1 className="text-4xl font-bold text-gray-800">{settings.channel_name}</h1>
        <p className="mt-2 text-gray-600">{settings.channel_description}</p>
      </div>

      {/* Main Content */}
      {threadView ? (
        <div>
          <button onClick={() => setThreadView(null)} className="mb-4 text-blue-600 hover:underline">
            &rarr; חזרה לפיד הראשי
          </button>
          <h2 className="text-xl font-bold mb-4">שרשור תגובות</h2>
          <div className="space-y-4">
            {getThreadPosts().map(post => (
                 <PostCard
                  key={post.id}
                  post={post}
                  isThreadView={true}
                  currentUserEmail={currentUser?.email || null}
                  canWrite={canWrite}
                  isAdmin={currentUser?.is_admin || false}
                  reactionEmojis={settings.reaction_emojis}
                  onReply={handleAction(setReplyingTo)}
                  onQuote={handleAction(setQuoting)}
                  onEdit={handleEdit}
                  onDelete={deletePost}
                  onReport={handleReport}
                  onReaction={addReaction}
                  onShowThread={() => {}}
                />
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {renderPosts(rootPosts)}
        </div>
      )}
      <div ref={feedEndRef} />

      {/* Editor */}
      {canWrite && (
        <div ref={editorRef} className="mt-8 sticky bottom-4 z-20">
          {(replyingTo || quoting || editing) && (
            <div className="bg-gray-100 text-sm p-2 rounded-t-lg flex justify-between items-center">
              <div>
                {editing && <span>עורכים הודעה</span>}
                {replyingTo && <span>מגיבים ל: <b>{replyingTo.created_by_name}</b></span>}
                {quoting && <span>מצטטים את: <b>{quoting.created_by_name}</b></span>}
              </div>
              <button onClick={cancelActions} className="text-red-500 font-bold">ביטול</button>
            </div>
          )}
          <RichTextEditor
            key={editing?.id || 'new'}
            initialContent={editing?.content || ''}
            onSend={handleSend}
            placeholder={replyingTo ? 'הוסף תגובה...' : 'כתוב הודעה חדשה...'}
            isSending={isSending}
          />
        </div>
      )}
    </div>
  );
};
