
import React from 'react';
import { User } from '../types';
import { MOCK_USERS, ADMIN_EMAIL } from '../constants';

interface HeaderProps {
  channelName: string;
  currentUser: User | null;
  page: string;
  setPage: (page: 'feed' | 'admin' | 'news') => void;
  onLogin: (user: User) => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ channelName, currentUser, page, setPage, onLogin, onLogout }) => {
  const canAccessNews = currentUser?.can_write || currentUser?.is_admin;
  const canAccessAdmin = currentUser?.is_admin;

  const handleLoginAs = (email: string) => {
    const user = MOCK_USERS.find(u => u.email === email);
    if (user) {
      onLogin(user);
    }
  };

  return (
    <header className="bg-white shadow-md w-full sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Right side: Logo and Navigation */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-xl font-bold text-gray-800 cursor-pointer" onClick={() => setPage('feed')}>{channelName}</h1>
            </div>
            <nav className="hidden md:block">
              <div className="mr-10 flex items-baseline space-x-4 space-x-reverse">
                <button
                  onClick={() => setPage('feed')}
                  className={`${page === 'feed' ? 'bg-gray-200 text-gray-900' : 'text-gray-600 hover:bg-gray-100'} px-3 py-2 rounded-md text-sm font-medium`}
                >
                  פיד ראשי
                </button>
                {canAccessNews && (
                  <button
                    onClick={() => setPage('news')}
                    className={`${page === 'news' ? 'bg-gray-200 text-gray-900' : 'text-gray-600 hover:bg-gray-100'} px-3 py-2 rounded-md text-sm font-medium`}
                  >
                    מקורות חדשות
                  </button>
                )}
                {canAccessAdmin && (
                  <button
                    onClick={() => setPage('admin')}
                    className={`${page === 'admin' ? 'bg-gray-200 text-gray-900' : 'text-gray-600 hover:bg-gray-100'} px-3 py-2 rounded-md text-sm font-medium`}
                  >
                    פאנל ניהול
                  </button>
                )}
              </div>
            </nav>
          </div>

          {/* Left side: User info / Login */}
          <div className="flex items-center">
            {currentUser ? (
              <div className="flex items-center">
                <span className="text-sm text-gray-700 ml-3">שלום, {currentUser.name}</span>
                <img className="h-8 w-8 rounded-full" src={currentUser.profile_image_url} alt={currentUser.name} />
                <button onClick={onLogout} className="mr-4 text-sm text-gray-500 hover:text-gray-800">התנתק</button>
              </div>
            ) : (
              <div className="flex items-center space-x-2 space-x-reverse">
                <span className="text-sm">התחבר כ:</span>
                <button onClick={() => handleLoginAs(ADMIN_EMAIL)} className="text-sm bg-red-100 text-red-700 px-2 py-1 rounded">מנהל</button>
                <button onClick={() => handleLoginAs('writer@example.com')} className="text-sm bg-green-100 text-green-700 px-2 py-1 rounded">כותב</button>
                <button onClick={() => handleLoginAs('user@example.com')} className="text-sm bg-blue-100 text-blue-700 px-2 py-1 rounded">משתמש</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
