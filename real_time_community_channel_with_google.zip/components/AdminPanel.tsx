
import React, { useState } from 'react';
import { SystemSettings, User, Report, ReportStatus, Post } from '../types';
import { TrashIcon, PencilIcon } from './icons/Icon';

// User Management Component
const UserManagement: React.FC<{ users: User[], updateUser: (email: string, updates: Partial<User>) => void }> = ({ users, updateUser }) => {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white">
        <thead className="bg-gray-50">
          <tr>
            <th className="py-3 px-6 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">משתמש</th>
            <th className="py-3 px-6 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">אימייל</th>
            <th className="py-3 px-6 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">מנהל</th>
            <th className="py-3 px-6 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">רשאי לכתוב</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {users.map(user => (
            <tr key={user.email}>
              <td className="py-4 px-6 whitespace-nowrap">
                <div className="flex items-center">
                  <img className="h-10 w-10 rounded-full ml-4" src={user.profile_image_url} alt={user.name} />
                  <div>
                    <div className="text-sm font-medium text-gray-900">{user.name}</div>
                  </div>
                </div>
              </td>
              <td className="py-4 px-6 whitespace-nowrap text-sm text-gray-500">{user.email}</td>
              <td className="py-4 px-6 whitespace-nowrap text-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" checked={user.is_admin} onChange={(e) => updateUser(user.email, { is_admin: e.target.checked })} />
              </td>
              <td className="py-4 px-6 whitespace-nowrap text-center">
                <input type="checkbox" className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" checked={user.can_write} onChange={(e) => updateUser(user.email, { can_write: e.target.checked })} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

// System Settings Component
const SystemSettingsEditor: React.FC<{ settings: SystemSettings, setSettings: (settings: SystemSettings) => void }> = ({ settings, setSettings }) => {
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;
        
        if (type === 'checkbox') {
            setSettings({ ...settings, [name]: checked });
        } else if (name === 'reaction_emojis' || name === 'categories') {
            setSettings({ ...settings, [name]: value.split(',').map(s => s.trim()) });
        }
        else {
            setSettings({ ...settings, [name]: value });
        }
    };
    
    return (
        <form className="space-y-6">
            <div>
                <label className="block text-sm font-medium text-gray-700">שם הערוץ</label>
                <input type="text" name="channel_name" value={settings.channel_name} onChange={handleInputChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
            </div>
             <div>
                <label className="block text-sm font-medium text-gray-700">תיאור הערוץ</label>
                <textarea name="channel_description" value={settings.channel_description} onChange={handleInputChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" rows={3}></textarea>
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700">לוגו הערוץ (URL)</label>
                <input type="text" name="channel_logo" value={settings.channel_logo} onChange={handleInputChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700">אימוג'ים לתגובה (מופרדים בפסיק)</label>
                <input type="text" name="reaction_emojis" value={settings.reaction_emojis.join(', ')} onChange={handleInputChange} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
            </div>
            <div className="flex items-center">
                <input type="checkbox" name="default_new_user_can_write" checked={settings.default_new_user_can_write} onChange={handleInputChange} className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
                <label className="mr-2 block text-sm text-gray-900">משתמשים חדשים יקבלו הרשאת כתיבה כברירת מחדל</label>
            </div>
        </form>
    );
};

// Reports Component
const ReportsManager: React.FC<{ reports: Report[], updateReportStatus: (id: string, status: ReportStatus) => void }> = ({ reports, updateReportStatus }) => {
    const statusClasses: { [key in ReportStatus]: string } = {
        pending: 'bg-yellow-100 text-yellow-800',
        reviewed: 'bg-blue-100 text-blue-800',
        resolved: 'bg-green-100 text-green-800',
    };
    const statusText: { [key in ReportStatus]: string } = {
        pending: 'ממתין',
        reviewed: 'בבדיקה',
        resolved: 'טופל',
    };
    
    return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white">
        <thead className="bg-gray-50">
          <tr>
            <th className="py-3 px-6 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">תוכן ההודעה</th>
            <th className="py-3 px-6 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">סיבה</th>
            <th className="py-3 px-6 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">מדווח</th>
            <th className="py-3 px-6 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">סטטוס</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {reports.map(report => (
            <tr key={report.id}>
              <td className="py-4 px-6 text-sm text-gray-500 max-w-sm truncate">{report.post_content}</td>
              <td className="py-4 px-6 whitespace-nowrap text-sm text-gray-900">{report.reason}</td>
              <td className="py-4 px-6 whitespace-nowrap text-sm text-gray-500">{report.reporter_email}</td>
              <td className="py-4 px-6 whitespace-nowrap text-center">
                <select 
                    value={report.status} 
                    onChange={(e) => updateReportStatus(report.id, e.target.value as ReportStatus)}
                    className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClasses[report.status]} border-none`}
                >
                  <option value="pending">ממתין</option>
                  <option value="reviewed">בבדיקה</option>
                  <option value="resolved">טופל</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};


type Tab = 'settings' | 'users' | 'reports';

interface AdminPanelProps {
    users: User[];
    settings: SystemSettings;
    reports: Report[];
    updateUser: (email: string, updates: Partial<User>) => void;
    setSettings: (settings: SystemSettings) => void;
    updateReportStatus: (id: string, status: ReportStatus) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ users, settings, reports, updateUser, setSettings, updateReportStatus }) => {
  const [activeTab, setActiveTab] = useState<Tab>('settings');

  const tabs: { id: Tab; label: string }[] = [
    { id: 'settings', label: 'הגדרות מערכת' },
    { id: 'users', label: 'ניהול משתמשים' },
    { id: 'reports', label: 'דיווחים' },
  ];

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">פאנל ניהול</h1>
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-4 space-x-reverse" aria-label="Tabs">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
      <div className="mt-8 bg-white p-6 rounded-lg shadow">
        {activeTab === 'settings' && <SystemSettingsEditor settings={settings} setSettings={setSettings} />}
        {activeTab === 'users' && <UserManagement users={users} updateUser={updateUser} />}
        {activeTab === 'reports' && <ReportsManager reports={reports} updateReportStatus={updateReportStatus} />}
      </div>
    </div>
  );
};
