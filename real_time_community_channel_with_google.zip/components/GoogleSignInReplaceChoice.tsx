import React, { useEffect, useRef } from "react";

type Props = {
  clientId: string;
  onSuccess: (response: any) => void;
  onError?: (err: any) => void;
  buttonText?: string;
  promptOneTap?: boolean;
};

const GoogleSignInReplaceChoice: React.FC<Props> = ({
  clientId,
  onSuccess,
  onError = (err) => console.error("Google sign-in error", err),
  buttonText = "התחבר עם Google",
  promptOneTap = false,
}) => {
  const buttonRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!clientId) {
      onError(new Error("Missing Google clientId"));
      return;
    }

    if (!(window as any).google?.accounts) {
      const script = document.createElement("script");
      script.src = "https://accounts.google.com/gsi/client";
      script.async = true;
      script.defer = true;
      script.onload = initializeGSI;
      script.onerror = () =>
        onError(new Error("Failed to load Google Identity Services"));
      document.head.appendChild(script);
    } else {
      initializeGSI();
    }

    return () => {
      try {
        (window as any).google?.accounts?.id?.cancel();
      } catch (e) {}
    };

    function initializeGSI() {
      try {
        (window as any).google.accounts.id.initialize({
          client_id: clientId,
          callback: handleCredentialResponse,
          auto_select: false,
          cancel_on_tap_outside: true,
        });

        if (promptOneTap) {
          (window as any).google.accounts.id.prompt();
        }
      } catch (err) {
        onError(err);
      }
    }

    function handleCredentialResponse(response: any) {
      onSuccess(response);
    }
  }, [clientId, onSuccess, onError, promptOneTap]);

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="p-4 rounded-2xl shadow-md bg-white">
        <h2 className="text-lg font-semibold mb-2">התחברות</h2>
        <p className="text-sm text-slate-600 mb-4">
          במקום הבחירה — התחבר עם חשבון ה‑Google שלך
        </p>

        <div className="flex gap-3 items-center">
          <button
            onClick={() => {
              try {
                (window as any).google.accounts.id.prompt();
              } catch (err) {
                onError(err);
              }
            }}
            className="flex items-center gap-3 px-4 py-2 rounded-xl border hover:shadow-sm focus:outline-none"
            aria-label={buttonText}
          >
            <svg
              width="20"
              height="20"
              viewBox="0 0 533.5 544.3"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden
            >
              <path d="M533.5 278.4c0-17.4-1.5-34.1-4.3-50.4H272v95.4h146.9c-6.3 34.2-25.3 63.2-54 82.6v68h87.2c51-47 80.4-116.3 80.4-195.6z" />
              <path d="M272 544.3c73.7 0 135.5-24.4 180.7-66.4l-87.2-68c-24.2 16.2-55.4 25.7-93.5 25.7-71.8 0-132.6-48.4-154.4-113.4H28.6v71.1C74.1 491.5 167.2 544.3 272 544.3z" />
              <path d="M117.6 322.2c-11.1-33.6-11.1-69.8 0-103.4V147.7H28.6c-39.2 76.6-39.2 171.4 0 248l89-72.5z" />
              <path d="M272 107.7c39 0 74.1 13.4 101.7 39.8l76.2-76.2C407.4 24 345.6 0 272 0 167.2 0 74.1 52.8 28.6 147.7l89 71.1C139.4 156.1 200.2 107.7 272 107.7z" />
            </svg>

            <span className="text-sm font-medium">{buttonText}</span>
          </button>
        </div>

        <p className="mt-3 text-xs text-slate-500">
          נדרש חשבון Google. האימות ישלח טוקן שאותו אפשר לאמת בשרת שלך.
        </p>
      </div>
    </div>
  );
};

export default GoogleSignInReplaceChoice;
