
import React, { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { PaperclipIcon, SendIcon } from './icons/Icon';

interface RichTextEditorProps {
  initialContent?: string;
  onSend: (content: string) => void;
  placeholder?: string;
  isSending: boolean;
}

export const RichTextEditor: React.FC<RichTextEditorProps> = ({ initialContent = '', onSend, placeholder, isSending }) => {
  const [content, setContent] = useState(initialContent);
  const editorRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setContent(initialContent);
  }, [initialContent]);

  const applyFormat = (tag: 'b' | 'i' | 'u' | 'code') => {
    const editor = editorRef.current;
    if (!editor) return;

    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    const selectedText = content.substring(start, end);
    const newContent = `${content.substring(0, start)}<${tag}>${selectedText}</${tag}>${content.substring(end)}`;
    
    setContent(newContent);
    editor.focus();
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if (content.trim() && !isSending) {
      onSend(content);
      setContent('');
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-2 border-b border-gray-200">
        <div className="flex items-center space-x-2 space-x-reverse">
          <button onClick={() => applyFormat('b')} className="px-2 py-1 text-sm font-bold rounded hover:bg-gray-100">B</button>
          <button onClick={() => applyFormat('i')} className="px-2 py-1 text-sm italic rounded hover:bg-gray-100">I</button>
          <button onClick={() => applyFormat('u')} className="px-2 py-1 text-sm underline rounded hover:bg-gray-100">U</button>
          <button onClick={() => applyFormat('code')} className="px-2 py-1 text-sm font-mono rounded hover:bg-gray-100">&lt;/&gt;</button>
          <button className="p-1 rounded hover:bg-gray-100" onClick={() => alert('העלאת קבצים עדיין בפיתוח.')}>
            <PaperclipIcon className="w-5 h-5" />
          </button>
        </div>
      </div>
      <div className="p-2">
        <textarea
          ref={editorRef}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder || "כתוב הודעה... (Ctrl+Enter לשליחה)"}
          className="w-full h-24 p-2 border-none focus:ring-0 resize-y"
          disabled={isSending}
        />
      </div>
      <div className="p-2 border-t border-gray-200 flex justify-between items-center">
        <span className="text-xs text-gray-500">תמיכה ב-HTML. השתמש ב-Shift+Enter לשורה חדשה.</span>
        <button
          onClick={handleSend}
          disabled={isSending || !content.trim()}
          className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 disabled:bg-blue-300 disabled:cursor-not-allowed flex items-center"
        >
          {isSending ? 'שולח...' : <><SendIcon className="w-5 h-5 ml-2" /> שלח</>}
        </button>
      </div>
    </div>
  );
};
