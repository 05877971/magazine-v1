
import React, { useState } from 'react';
import { NewsDraft } from '../types';
import { RichTextEditor } from './RichTextEditor';
import { fetchNewsFromSource } from '../services/geminiService';
import { TrashIcon, PencilIcon } from './icons/Icon';

interface NewsSourcesProps {
  drafts: NewsDraft[];
  addDraft: (draft: Omit<NewsDraft, 'id' | 'is_published'>) => Promise<void>;
  updateDraft: (id: string, content: string) => Promise<void>;
  deleteDraft: (id: string) => Promise<void>;
  publishDraft: (draft: NewsDraft) => Promise<void>;
}

export const NewsSources: React.FC<NewsSourcesProps> = ({ drafts, addDraft, updateDraft, deleteDraft, publishDraft }) => {
  const [source, setSource] = useState('TechCrunch');
  const [isLoading, setIsLoading] = useState(false);
  const [editingDraft, setEditingDraft] = useState<NewsDraft | null>(null);

  const handleFetch = async () => {
    if (!source) {
      alert('אנא הזן שם מקור (לדוגמה, ערוץ טלגרם).');
      return;
    }
    setIsLoading(true);
    try {
      const content = await fetchNewsFromSource(source);
      await addDraft({ source, content });
    } catch (error) {
      console.error("Failed to fetch news:", error);
      alert('שגיאה בשליפת החדשות.');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePublish = async () => {
    if (editingDraft) {
      await publishDraft(editingDraft);
      setEditingDraft(null);
    }
  };
  
  const handleSaveEdit = async (content: string) => {
    if (editingDraft) {
        await updateDraft(editingDraft.id, content);
    }
  }

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">מקורות חדשות</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Left Column: Drafts List */}
        <div className="md:col-span-1">
          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-xl font-bold mb-4">שליפת תוכן חדש</h2>
            <div className="space-y-4">
              <div>
                <label htmlFor="source" className="block text-sm font-medium text-gray-700">שם המקור (למשל, ערוץ טלגרם)</label>
                <input
                  type="text"
                  id="source"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                  placeholder="לדוגמה: ynet"
                />
              </div>
              <button
                onClick={handleFetch}
                disabled={isLoading}
                className="w-full bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 disabled:bg-blue-300"
              >
                {isLoading ? 'שולף מידע...' : 'שלף באמצעות AI'}
              </button>
            </div>
            <hr className="my-6" />
            <h3 className="text-lg font-bold mb-2">טיוטות</h3>
            <ul className="space-y-2 max-h-96 overflow-y-auto">
              {drafts.map(draft => (
                <li
                  key={draft.id}
                  className={`p-2 rounded cursor-pointer flex justify-between items-center ${editingDraft?.id === draft.id ? 'bg-blue-100' : 'hover:bg-gray-100'}`}
                  onClick={() => setEditingDraft(draft)}
                >
                  <div>
                    <span className="font-semibold">{draft.source}</span>
                    {draft.is_published && <span className="text-xs text-green-600 mr-2">(פורסם)</span>}
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                     <button onClick={(e) => { e.stopPropagation(); setEditingDraft(draft); }} className="text-gray-400 hover:text-green-500"><PencilIcon className="w-4 h-4" /></button>
                    <button onClick={(e) => { e.stopPropagation(); deleteDraft(draft.id); }} className="text-gray-400 hover:text-red-500"><TrashIcon className="w-4 h-4" /></button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right Column: Editor */}
        <div className="md:col-span-2">
          <div className="bg-white p-4 rounded-lg shadow">
            <h2 className="text-xl font-bold mb-4">עריכת טיוטה</h2>
            {editingDraft ? (
              <div>
                <RichTextEditor
                    key={editingDraft.id}
                    initialContent={editingDraft.content}
                    onSend={handleSaveEdit}
                    isSending={false} // Here onSend is for saving, not publishing
                />
                <button
                  onClick={handlePublish}
                  disabled={editingDraft.is_published}
                  className="mt-4 w-full bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 disabled:bg-green-300"
                >
                  {editingDraft.is_published ? 'פורסם' : 'פרסם לפיד'}
                </button>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-16">
                בחר טיוטה מהרשימה או שלוף תוכן חדש כדי להתחיל.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
