
import React, { useState, useEffect, useRef } from 'react';
import { Post } from '../types';
import { EyeIcon, LinkIcon, WarningIcon, TrashIcon, PencilIcon, QuoteIcon, ReplyIcon, PlusIcon } from './icons/Icon';

interface PostCardProps {
  post: Post;
  isThreadView?: boolean;
  currentUserEmail: string | null;
  canWrite: boolean;
  isAdmin: boolean;
  reactionEmojis: string[];
  onReply: (post: Post) => void;
  onQuote: (post: Post) => void;
  onEdit: (post: Post) => void;
  onDelete: (postId: string) => void;
  onReport: (post: Post) => void;
  onReaction: (postId: string, emoji: string) => void;
  onShowThread: (post: Post) => void;
}

const Tooltip: React.FC<{ text: string; children: React.ReactNode }> = ({ text, children }) => (
  <div className="relative group">
    {children}
    <div className="absolute bottom-full mb-2 hidden group-hover:block w-max bg-gray-800 text-white text-xs rounded py-1 px-2 z-10">
      {text}
    </div>
  </div>
);

export const PostCard: React.FC<PostCardProps> = ({
  post, isThreadView = false, currentUserEmail, canWrite, isAdmin, reactionEmojis,
  onReply, onQuote, onEdit, onDelete, onReport, onReaction, onShowThread
}) => {
  const [highlighted, setHighlighted] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (window.location.hash === `#post-${post.id}`) {
      setHighlighted(true);
      setTimeout(() => setHighlighted(false), 2000);
    }
  }, [post.id]);
  
  const canPerformActions = canWrite || isAdmin;
  const canEditOrDelete = isAdmin || (currentUserEmail === post.created_by_email);
  
  const copyLink = () => {
    const link = `${window.location.origin}${window.location.pathname}#post-${post.id}`;
    navigator.clipboard.writeText(link);
    setHighlighted(true);
    setTimeout(() => setHighlighted(false), 2000);
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('he-IL', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit'
    });
  }

  return (
    <div
      id={`post-${post.id}`}
      ref={cardRef}
      className={`bg-white rounded-lg shadow-sm border border-gray-200 transition-all duration-500 ${highlighted ? 'border-blue-500 ring-2 ring-blue-300' : ''} ${post.parent_post_id && !isThreadView ? 'mr-8' : ''}`}
    >
      <div className="p-4">
        {/* Toolbar */}
        <div className="flex items-center space-x-3 space-x-reverse text-gray-500 text-xs mb-2 float-left">
          <div className="flex items-center"><EyeIcon className="w-4 h-4 ml-1" /> {post.view_count}</div>
          <Tooltip text="העתק קישור"><button onClick={copyLink} className="hover:text-blue-500"><LinkIcon className="w-4 h-4" /></button></Tooltip>
          {currentUserEmail && <Tooltip text="דווח"><button onClick={() => onReport(post)} className="hover:text-red-500"><WarningIcon className="w-4 h-4" /></button></Tooltip>}
          {canEditOrDelete && <Tooltip text="מחק"><button onClick={() => onDelete(post.id)} className="hover:text-red-500"><TrashIcon className="w-4 h-4" /></button></Tooltip>}
          {canEditOrDelete && canWrite && <Tooltip text="ערוך"><button onClick={() => onEdit(post)} className="hover:text-green-500"><PencilIcon className="w-4 h-4" /></button></Tooltip>}
          {canPerformActions && <Tooltip text="צטט"><button onClick={() => onQuote(post)} className="hover:text-indigo-500"><QuoteIcon className="w-4 h-4" /></button></Tooltip>}
          {canPerformActions && <Tooltip text="הגב בשרשור"><button onClick={() => onReply(post)} className="hover:text-blue-500"><ReplyIcon className="w-4 h-4" /></button></Tooltip>}
        </div>

        {/* Post Body */}
        <div className="flex items-start">
          <img src={post.created_by_profile_image} alt={post.created_by_name} className="w-10 h-10 rounded-full ml-4" />
          <div className="flex-1">
            <div className="flex items-baseline space-x-2 space-x-reverse">
              <span className="font-bold text-gray-800">{post.created_by_name}</span>
              <span className="text-xs text-gray-400">{formatDate(post.created_at)}</span>
            </div>
             {post.quoted_post && (
              <div className="post-quote mt-2">
                <div className="font-semibold">{post.quoted_post.created_by_name} כתב:</div>
                <div className="message-content" dangerouslySetInnerHTML={{ __html: post.quoted_post.content.substring(0, 100) + '...' }} />
              </div>
            )}
            <div className="mt-1 text-gray-700 message-content" dangerouslySetInnerHTML={{ __html: post.content }} />
          </div>
        </div>

        {/* Reactions and Thread */}
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-1 space-x-reverse">
            {reactionEmojis.map(emoji => {
              const users = post.reactions[emoji] || [];
              const userReacted = currentUserEmail && users.includes(currentUserEmail);
              return (
                <button
                  key={emoji}
                  onClick={() => onReaction(post.id, emoji)}
                  disabled={!currentUserEmail}
                  className={`px-2 py-1 border rounded-full text-sm transition-colors ${userReacted ? 'bg-blue-100 border-blue-500' : 'bg-gray-100 border-gray-200 hover:bg-gray-200'} disabled:cursor-not-allowed`}
                >
                  {emoji} {users.length > 0 && <span className="text-xs">{users.length}</span>}
                </button>
              );
            })}
            {currentUserEmail && <Tooltip text="הוסף תגובה"><button className="p-1.5 border rounded-full bg-gray-100 hover:bg-gray-200"><PlusIcon className="w-4 h-4 text-gray-500" /></button></Tooltip>}
          </div>
          {post.reply_count > 0 && !isThreadView && (
             <button onClick={() => onShowThread(post)} className="text-sm text-blue-600 hover:underline">
              {post.reply_count} {post.reply_count === 1 ? 'תגובה' : 'תגובות'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
